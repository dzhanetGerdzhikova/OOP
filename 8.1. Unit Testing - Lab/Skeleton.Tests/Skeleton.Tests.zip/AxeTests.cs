using NUnit.Framework;
using Skeleton.Tests;

[TestFixture]
public class AxeTests : BaseTest
{
    //[Test]
    //public void WeaponLosesDurabilityAfterAttack()
    //{
    //    Assert.That(axe.DurabilityPoints, Is.EqualTo(9), "Durability doesn't change after attack.");
    //}

    //[Test]
    //public void AttackingWithBrokenWeaponThrowsException()
    //{
    //    axe.Attack(dummy);
    //    Assert.That(() => axe.Attack(dummy), Throws.InvalidOperationException, "Attacking with broken weapon didn't throws exception");
    //}
}