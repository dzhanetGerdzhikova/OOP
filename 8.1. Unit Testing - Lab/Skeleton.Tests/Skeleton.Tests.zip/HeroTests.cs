﻿using NUnit.Framework;
using Skeleton.Tests;

[TestFixture]
public class HeroTests : BaseTest
{
    [Test]
    public void HeroBecomeXPWhenDummyIsDead()
    {
        FakeAxe fakeAxe = new FakeAxe();
        FakeDummy fakeDummy = new FakeDummy(true);

        hero.Attack(fakeDummy);
        Assert.That(hero.Experience, Is.EqualTo(20));
    }

    [Test]
    public void HeroDidntBecameXPWhenDummyIsDead()
    {
        FakeAxe fakeAxe = new FakeAxe();
        FakeDummy fakeDummy = new FakeDummy(false);

        hero.Attack(fakeDummy);
        Assert.That(hero.Experience, Is.EqualTo(0));
    }
}