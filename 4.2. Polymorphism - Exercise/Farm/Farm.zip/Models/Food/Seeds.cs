﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm.Models.Food
{
  public  class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
