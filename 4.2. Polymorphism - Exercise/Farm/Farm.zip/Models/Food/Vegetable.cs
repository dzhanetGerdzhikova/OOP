﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm.Models.Food
{
    class Vegetable:Food
    {
        public Vegetable(int quantity)
            :base (quantity)
        {

        }
    }
}
