﻿namespace SantaWorkshop.IO.Contracts
{
    public interface IRepository
    {
        string ReadLine();
    }
}