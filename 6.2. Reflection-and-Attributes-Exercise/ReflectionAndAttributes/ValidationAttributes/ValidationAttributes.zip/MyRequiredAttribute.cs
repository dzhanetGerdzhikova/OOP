﻿using System;
using System.Reflection;

namespace ValidationAttributes
{
    public class MyRequiredAttribute : MyValidationAttribute
    {
        public override bool IsValid(object obj)
        {
            //Type type = obj?.GetType();
            //var attribute = type?.GetCustomAttribute<MyRequiredAttribute>();

            return obj != null;
        }
    }
}